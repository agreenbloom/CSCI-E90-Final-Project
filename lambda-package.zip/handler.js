const { Pool } = require('pg');

// Configure the PostgreSQL connection pool
const pool = new Pool({
    host: process.env.PG_HOST,      // RDS endpoint
    port: process.env.PG_PORT || 5432, // Default PostgreSQL port
    user: process.env.PG_USER,     // Database username
    password: process.env.PG_PASS, // Database password
    database: process.env.PG_DB,   // Database name
});

exports.handler = async (event) => {
    let client;
    try {
        // Get a database client from the pool
        client = await pool.connect();

        // Example query: Get the current server time
        const result = await client.query('SELECT NOW() AS current_time');
        console.log('Query result:', result.rows[0]);

        return {
            statusCode: 200,
            body: JSON.stringify({
                message: 'Connection successful',
                currentTime: result.rows[0].current_time,
            }),
        };
    } catch (error) {
        console.error('Database connection error:', error);

        return {
            statusCode: 500,
            body: JSON.stringify({
                message: 'Failed to connect to database',
                error: error.message,
            }),
        };
    } finally {
        // Release the client back to the pool
        if (client) {
            client.release();
        }
    }
};
